﻿using System;
using NUnit.Framework;
using Beadando;

namespace BeadandoTeszt
{
    [TestFixture]
    public class AutokTesztek
    {
        [Test]
        public void AutokKonstruktorTeszt_Veletlenszeru()
        {
            // Arrange & Act
            Autok auto = new Autok();

            // Assert
            Assert.Greater(auto.Puttony, 0);
            Assert.Greater(auto.Uzemanyag, 0);
            Assert.Greater(auto.Fogyasztas, 0);
            Assert.AreEqual(0, auto.PuttonyKezdo);
            Assert.AreEqual(auto.Uzemanyag, auto.UzemanyagKezdo);
            Assert.IsNotNull(auto.Koordinatak);
            Assert.AreEqual(2, auto.Koordinatak.Count);
        }

        [Test]
        public void AutokKonstruktorTeszt_Fajlbol()
        {
            // Arrange
            string sor = "100 2000 5 0 100 10 20";

            // Act
            Autok auto = new Autok(sor);

            // Assert
            Assert.AreEqual(100, auto.Uzemanyag);
            Assert.AreEqual(2000, auto.Puttony);
            Assert.AreEqual(5, auto.Fogyasztas);
            Assert.AreEqual(0, auto.PuttonyKezdo);
            Assert.AreEqual(100, auto.UzemanyagKezdo);
            Assert.AreEqual(10, auto.Koordinatak[0]);
            Assert.AreEqual(20, auto.Koordinatak[1]);
        }
    }
}