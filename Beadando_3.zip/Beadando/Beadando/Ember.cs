﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Beadando
{
    class Ember
    {
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        private List<int> koordinatak = new List<int>();
        private int kuka, mennyiszemet, fizetes;
        private bool voltEmar;


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        private List<int> kukameretek = new List<int>() { 50, 60, 70, 80, 90, 100, 110, 120 };
        static private Random r = new Random();
        public bool VoltEMar { get { return voltEmar; } set { voltEmar = value; } }
        public int Mennyiszemet { get { return mennyiszemet; } set { mennyiszemet = value; } }
        public List<int> Koordinatak { get { return koordinatak; } set { koordinatak = value; } }
        public int Kuka { get { return kuka; } set { kuka = value; } }
        public int Fizetes { get { return fizetes; } }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Ez az "Ember" osztaly egyik konstruktora, ezt akkor hasznalja program, ha az adatok veletlenszeruek.
        /// </summary>
        /// <param name="randomhazak">A parameter azert szukseges hogy a vegen ellenorizni tudjuk hogy, ketto haz ne legyen ugyan azon a koordinatan.</param>
        /// <param name="i">Az "i" is ezert szukseges.</param>
        public Ember(int randomhazak, int i)
        {
                List<int> egy = Generalas();
                koordinatak.Add(egy[0]);
                koordinatak.Add(egy[1]);
                kuka = kukameretek[r.Next(0, kukameretek.Count - 1)];
                mennyiszemet = r.Next(30, kuka);
                voltEmar = false;
                fizetes = kuka * 50;
                if (i == randomhazak)
                {
                    Ellenorzes();
                }
        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Ez a masik konstruktor. Ezt csak akkor hasznalja ha egy fajlbol olvasunk be.
        /// </summary>
        /// <param name="sr">Ez egy sor a beolvasott fajlbol</param>
        public Ember(string sr)
        {
            string[] sorsplit = sr.Split(' ');
            koordinatak.Add(Convert.ToInt32(sorsplit[0]));
            koordinatak.Add(Convert.ToInt32(sorsplit[1]));
            kuka = Convert.ToInt32(sorsplit[2]);
            mennyiszemet = Convert.ToInt32(sorsplit[3]);
            fizetes = Convert.ToInt32(sorsplit[4]);
            voltEmar = Convert.ToBoolean(sorsplit[5]);
        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Ez a fuggveny a koordinatak generalasaban segit. Feltolt egy tombot 2 random adattal 0 es 300 kozott.
        /// </summary>
        /// <returns>Visszaad egy listat amit az elso konstruktorban felhasznalunk</returns>
        private List<int> Generalas()
        {
            List<int> general = new List<int>();
            general.Add(r.Next(0, 301));
            general.Add(r.Next(0, 301));
            return general;


        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// A fuggveny arra szolgal hogy a koordinatak tombben ne keletkezzen duplikaciok es hogy a hazak koordianatai ne a 0:0ak legyenek (szemettelep es benzinkut helye).
        /// </summary>
        private void Ellenorzes()
        {
            for (int i = 0; i < koordinatak.Count - 1; i += 2)
            {
                for (int j = 0; j < koordinatak.Count - 1; j += 2)
                {
                    if ((koordinatak[i] == koordinatak[j] && koordinatak[i + 1] == koordinatak[j + 1]) || (koordinatak[i] == 0 && koordinatak[i + 1] == 0))
                    {
                        koordinatak[i] += r.Next(0, 301);
                        koordinatak[i + 1] += r.Next(0, 301);
                        i = i - 2;


                    }
                }
            }


        }

        




    }



}
