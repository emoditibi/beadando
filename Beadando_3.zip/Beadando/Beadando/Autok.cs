﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Beadando
{
    public class Autok
    {
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        private int fogyasztas, puttony, uzemanyag;
        private int uzemanyagkezdo;
        private double puttonykezdo;
        List<int> koordinatak = new List<int>();
        static private Random r = new Random();


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        public double PuttonyKezdo { get { return puttonykezdo; } set { puttonykezdo = value; } }
        public int Puttony { get { return puttony; } }

        public int UzemanyagKezdo { get { return uzemanyagkezdo; } set { uzemanyagkezdo = value; } }
        public int Fogyasztas { get { return fogyasztas; } }
        public int Uzemanyag { get { return uzemanyag; } }
        public List<int> Koordinatak { get { return koordinatak; } set { koordinatak = value; } }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Ez az egyik konstruktora az "Autok" osztalynak. Ezt a konstruktort akkor hasznalja a program ha az adatok veletlenszeruek.
        /// </summary>
        public Autok()
        {
            int uzem = r.Next(800, 1201);
            uzemanyag = uzem;
            puttony = r.Next(1200, 8900);
            fogyasztas = r.Next(1, 6);
            puttonykezdo = 0;
            uzemanyagkezdo = uzem;
            for (int i = 0; i < 2; i++)
            {
                koordinatak.Add(0);
                koordinatak.Add(0);
            }
        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Ez a masik konstruktor. Ezt csak akkor hasznalja ha egy fajlbol olvasunk be.
        /// <param name="sr">Ez egy sor a beolvasott fajlbol</param>
        /// </summary>
        public Autok(string sr)
        {
            string[] sorsplit = sr.Split(' ');
            uzemanyag = Convert.ToInt32(sorsplit[0]);
            puttony = Convert.ToInt32(sorsplit[1]);
            fogyasztas = Convert.ToInt32(sorsplit[2]);
            puttonykezdo = Convert.ToInt32(sorsplit[3]);
            uzemanyagkezdo = Convert.ToInt32(sorsplit[4]);
            koordinatak.Add(Convert.ToInt32(sorsplit[5]));
            koordinatak.Add(Convert.ToInt32(sorsplit[6]));
        }

        
    }
}








    
