﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beadando
{
    public class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("f: fajlbeolvasas");
            Console.WriteLine("barmilyen masik karakter: szimulacio");
            
            Szimulacio sz = new Szimulacio(Console.ReadLine());
            
            Console.ReadLine();



        }
    }
}
