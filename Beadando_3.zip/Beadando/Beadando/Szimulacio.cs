﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace Beadando
{
    public class Szimulacio
    {
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        private List<Ember> emberek = new List<Ember>();
        private List<Autok> autok = new List<Autok>();
        private KukaSzimulator kukaSzimulator;
        private int randomhaz, tavolsagkoordinata, mennyitfizet;
        private string hanyadikfajl="";
        static private Random r = new Random();


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        public Szimulacio(string betu)
        {
            
            if (betu == "f" || betu =="F")
            {
                MiTortenjenFajlBeolvasas();
            }
            else
            {
                MiTortenjenRandom();
            }
            kukaSzimulator = new KukaSzimulator(autok.Count);
            FoProgram();
            Console.WriteLine();
            


        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        private void MiTortenjenFajlBeolvasas()
        {
            Console.Clear();
            Console.WriteLine("Kerem irja be a megfelelo szot a tovabbjutashoz (nagy- es kisbetu kulonbozik):");
            Console.WriteLine("kicsi\nkozepes\nnagy");
            string beolvasas = Console.ReadLine();
            string beolvasasauto = "";
            if (beolvasas == "nagy" || beolvasas == "kicsi" || beolvasas == "kozepes")
            {
                hanyadikfajl = beolvasas + ".txt";
                beolvasasauto = beolvasas + "-auto.txt";
                randomhaz = 0;
                emberek = Array.ConvertAll(File.ReadAllLines(hanyadikfajl), (sor) => new Ember(sor)).ToList();
                autok = Array.ConvertAll(File.ReadAllLines(beolvasasauto), (sor) => new Autok(sor)).ToList();
                int randomauto = autok.Count;
            }
            else
            {
                Console.WriteLine("Nem azt a szot adta meg");
                new Szimulacio("f");

            }
        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        private void MiTortenjenRandom()
        {
            randomhaz = r.Next(20, 4001);
            for (int i = 0; i < randomhaz; i++)
            {
                emberek.Add(new Ember(randomhaz, i));
            }
            int randomauto = Convert.ToInt32(Math.Ceiling((double)randomhaz / 500));
            for (int i = 0; i < randomauto; i++)
            {
                autok.Add(new Autok());
            }
        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        private void FoProgram()
        {
            for (int i = 0; i < emberek.Count; i++)
            {
                for (int ranauto = 0; ranauto < autok.Count; ranauto++)
                {

                    tavolsagkoordinata = MinimumIndex(ranauto);
                    if (tavolsagkoordinata >= 0)
                    {
                        FoProgramMasikResze(ranauto,i);
                    }
                }
                mennyitfizet += emberek[i].Fizetes;

            }
        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        private void FoProgramMasikResze(int ranauto, int i)
        {
            if (i == emberek.Count - 1)
            {
                statok(tavolsagkoordinata, ranauto, true, mennyitfizet);
            }
            statok(tavolsagkoordinata, ranauto, false, mennyitfizet);
            autok[ranauto].PuttonyKezdo = autok[ranauto].PuttonyKezdo + (emberek[tavolsagkoordinata].Mennyiszemet * 0.75);
            emberek[tavolsagkoordinata].VoltEMar = true;
            emberek[tavolsagkoordinata].Mennyiszemet = 0;
            autok[ranauto].Koordinatak[0] = emberek[tavolsagkoordinata].Koordinatak[0];
            autok[ranauto].Koordinatak[1] = emberek[tavolsagkoordinata].Koordinatak[1];
            autok[ranauto].UzemanyagKezdo -= autok[ranauto].Fogyasztas;
            kukaSzimulator.miTortenik(false, autok[ranauto].PuttonyKezdo, autok, ranauto);
        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        private void statok(int tavolsagkoordinata, int ranauto,bool eldont, int mennyitfizet)
        {
            StatisztikaAdatok statisztikaAdatok = Ellenorzes(tavolsagkoordinata, ranauto, eldont, mennyitfizet);
            if (eldont)
            {
                Console.WriteLine(statisztikaAdatok);
            }
        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        private StatisztikaAdatok Ellenorzes(int minimumtavolsag, int autoindex,bool vegevane, int mennyitfizet)
        {
            StatisztikaAdatok adatok = new StatisztikaAdatok(emberek.Count, mennyitfizet, vegevane);
            if (((autok[autoindex].UzemanyagKezdo - autok[autoindex].Fogyasztas) <= autok[autoindex].Fogyasztas)||vegevane)
            {
                adatok.UzemanyagMennyiseg = (autok[autoindex].Uzemanyag - autok[autoindex].UzemanyagKezdo);
                adatok.HanyszorTankoltak++;
                autok[autoindex].UzemanyagKezdo += autok[autoindex].Uzemanyag;
                autok[autoindex].Koordinatak[0] = 0;
                autok[autoindex].Koordinatak[1] = 0;

            }
            if (((autok[autoindex].PuttonyKezdo + emberek[minimumtavolsag].Mennyiszemet) > autok[autoindex].Puttony)||vegevane)
            {
                adatok.SzemetMennyiseg = autok[autoindex].PuttonyKezdo;
                adatok.HanyszorSzemeteltek++;
                autok[autoindex].PuttonyKezdo = 0;
                autok[autoindex].Koordinatak[0] = 0;
                autok[autoindex].Koordinatak[1] = 0;
                kukaSzimulator.miTortenik(true, 0, autok, autoindex);
            }
            return adatok;
        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        private int MinimumIndex(int autoindex)
        {

            Dictionary<int, double> tavolsagok = new Dictionary<int, double>();
            for (int i = 0; i < emberek.Count; i++)
            {
                if (!emberek[i].VoltEMar)
                {
                    tavolsagok.Add(i, Math.Sqrt((Math.Pow(Convert.ToDouble(autok[autoindex].Koordinatak[0] - emberek[i].Koordinatak[0]), 2) +
                                              Math.Pow(Convert.ToDouble(autok[autoindex].Koordinatak[1] - emberek[i].Koordinatak[1]), 2))));
                }
            }
            return MinimumIndexEldontes(tavolsagok);
            

        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        private int MinimumIndexEldontes(Dictionary<int, double> tavolsagok)
        {
            if (tavolsagok.Count != 0)
            {
                return tavolsagok.OrderBy(x => x.Value).First().Key;
            }
            else
            {
                return -1;
            }
        }
    }
}






