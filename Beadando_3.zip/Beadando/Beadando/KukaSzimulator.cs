﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Beadando
{
    public class KukaSzimulator
    {
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        private string[,] hazak;
        private char[] karakterek;
        private string[] egykuka = {
                "       ___/-\\___          ",
                "      |---------|         ",
                "       |       |          ",
                "       |       |          ",
                "       |       |          ",
                "       |       |          ",
                "       |       |          ",
                "       =========          "};
        private bool tele; 
        private string[] autostat ={" ","Szemet :",     "Kapacitasa :","Jelenlegi benzin :","Mennyi üzemanyag :",     "Fogyasztasa :"};
        private string teli = "       |///////|          ";
        private double[] mennyirevantele;
        private int kar;


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        public string[] Autostat { get { return autostat; } set { autostat = value; } }
        public KukaSzimulator(int kukasautokszama)
        {
            hazak = new string[kukasautokszama, 8];
            for (int i = 0; i < kukasautokszama; i++)
            {

                for (int j = 0; j < 8; j++)
                {
                    hazak[i, j] = egykuka[j];
                    



                }

                tele = false;
            }
            mennyirevantele = new double[kukasautokszama];
        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        private void Kiszamol(List<Autok> autok)
        {
            for (int i = 1; i < autostat.Length; i++)
            {
                for (int j = 0; j < autok.Count; j++)
                {
                    karakterek = new char[0];
                    switch (i)
                    {
                        case 1:
                            
                            karakterek = (autostat[i] +autok[j].PuttonyKezdo).ToCharArray();
                            break;
                        case 2:
                            karakterek = (autostat[i] + autok[j].Puttony).ToCharArray();
                            break;
                        case 3:
                            karakterek = (autostat[i] + autok[j].UzemanyagKezdo).ToCharArray();
                            break;
                        case 4:
                            karakterek = (autostat[i] + autok[j].Uzemanyag).ToCharArray();
                            break;
                        case 5:
                            karakterek = (autostat[i] + autok[j].Fogyasztas).ToCharArray();
                            break;
                            
                    }
                    if (karakterek.Length <= 25)
                    {
                        kar = 25 - karakterek.Length;
                        AutoAdatok(kar);
                    }
                }
                Console.WriteLine();
            }
        }
        

        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        public void Kiiras(int meddig, int mennyiszer)
        {
            for (int j = 0; j < mennyiszer; j++)
            {

                for (int n = 0; n < meddig; n++)
                {

                    Console.Write(hazak[n,j]);
                }
                Console.WriteLine();
            }
        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        public void miTortenik(bool televane,double mennyivel, List<Autok> autok, int hanyadikauto)
        {
            if (televane)
            {
                for (int i = 0; i < 8; i++)
                {
                    
                    hazak[hanyadikauto, i] = egykuka[i];
                }
            }
            else
            {
                mennyirevantele[hanyadikauto] = 0.0;
                mennyirevantele[hanyadikauto] = mennyivel;

                double autoszazalek = autok[hanyadikauto].Puttony / 100*20;
                int hany = (int)Math.Floor(Convert.ToDecimal(mennyirevantele[hanyadikauto]/autoszazalek));
                
                if (hany>0)
                {
                    
                    for (int i = 6; i>=7-hany;i--)
                    {
                        Thread.Sleep(200);
                        Console.Clear();
                        Kiiras(hazak.GetLength(0),8);
                        
                        Kiszamol(autok);
                        hazak[hanyadikauto, i]=teli;

                    }
                }
            }
        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        public void AutoAdatok(int meddig)
        {
            
            string ures = "";
            for (int k = 0; k < meddig-1; k++)
            {
                ures += " ";
            }

            for (int j = 0; j < karakterek.Length; j++)
            {
                Console.Write(karakterek[j]);
            }
            Console.Write("L" + ures + "|");
            
        }
    }
}
