﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Beadando
{
    class FajlBeolvasasTeszteles
    {
        List<int> koordinatak = new List<int>();
        private int kuka, mennyiszemet,fizetes;
        private bool voltEmar;


        public FajlBeolvasasTeszteles(string fajlnev)
        {
            
            
        }
    }
}
