﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beadando
{
    public class StatisztikaAdatok
    {
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        private int emberekszama, vegosszeg,uzemanyag, tankdb, szemetdb;
        private double szemetmennyiseg;


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        public int UzemanyagMennyiseg { get {return uzemanyag; } set {uzemanyag=value; } }
        public int HanyszorTankoltak { get { return tankdb; } set {tankdb= value; } }
        public double SzemetMennyiseg { get { return szemetmennyiseg; } set {szemetmennyiseg= value; } }
        public int HanyszorSzemeteltek { get { return szemetdb; } set {szemetdb= value; } }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Ez a "StatisztikaAdatok" konstruktora
        /// </summary>
        /// <param name="emberekszamaa"></param>
        /// <param name="vegosszegi"></param>
        /// <param name="vegevane"></param>
        public StatisztikaAdatok(int emberekszamaa, int vegosszegi, bool vegevane)
        {
            if (vegevane)
            {
                vegosszeg = vegosszegi;
                emberekszama = emberekszamaa;
            }
        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------
        public override string ToString()
        {
            return $"A hazak szama: {emberekszama}\nMennyi uzemanyagot vettek: {UzemanyagMennyiseg}\nMennyi szemetet adtak le a szemettelepen: {SzemetMennyiseg}\nHanyszor tankoltak: {HanyszorTankoltak}\nHanyszor voltak a szemettelepen: {HanyszorSzemeteltek}\nMennyi lett volna a profitjuk ha az emberek\n20forintot fizetnek iterenkent és a benzinert pedig 300 forintot fizetnek\n {vegosszeg}\n";
        }
    }
}
